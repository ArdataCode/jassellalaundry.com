<?php
// Please validate auto_prepend_file setting before removing this file

if (file_exists('/home/1168435.cloudwaysapps.com/jaqdattwba/public_html/wp-content/plugins/malcare-security/protect/prepend/ignitor.php')) {
	define("MCDATAPATH", '/home/1168435.cloudwaysapps.com/jaqdattwba/public_html/wp-content/mc_data/');
	define("MCCONFKEY", 'bbe666e217275c2b5ad4ea6a4e84022c');
	include_once('/home/1168435.cloudwaysapps.com/jaqdattwba/public_html/wp-content/plugins/malcare-security/protect/prepend/ignitor.php');
}
