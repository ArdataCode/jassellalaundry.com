<?php
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 */
define('AUTH_KEY',         '29NwFgMc7bKI7jQEw3QsTHaRpPgRnVK3nhcEKfutvDfACrCuIaU8zsNw8TpdTobT');
define('SECURE_AUTH_KEY',  'In0oHMGFS8PzXqsfEo8wsEwTCgKoh0A5yxutuPUdTseMb2TEcCM4dSxevA4Sveet');
define('LOGGED_IN_KEY',    'e6to4YpAVRQX1pnmcrjmNz9YIIsB5Tfhg1mUoQv6bSraTN4G7NGRqMytdKBRM0eD');
define('NONCE_KEY',        'cMpFI8RNK4HYqYCq0JGJPbKpCXcovcF1RdWbVq6hKDnpcxfjMojJ3seuh5058GuD');
define('AUTH_SALT',        'Dum8jVBwoHamSNisiMearhE04TNMeBQqgWwFSux8Xg7Bh9AfHmuwQgMW4VyTnjvm');
define('SECURE_AUTH_SALT', 'PVfYwLYbqsX4oodshQtJmeDgYdJef48m2GcgbF2sAjw2y1REyIHmBHr9gIswRYM6');
define('LOGGED_IN_SALT',   'QmHGQmJWRYfIXeSiTYdENV55HVbNq5cG0792EUqdctsLJstCILQLNTW4SK80frgW');
define('NONCE_SALT',       'HrM0e06fhuCxQGYz1L4y4CLmUMp9hIExjK3pTG8I32xYI7qMWh1sVmb09uawB2g3');
